import { ShieldCheck } from "lucide-react";

export function Header() {
  return (
    <header className="glass-header w-full border-b shadow-sm mb-6">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-4">
            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 text-white shadow-lg shadow-primary/30">
              <ShieldCheck className="w-7 h-7" strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="text-2xl font-bold font-display tracking-tight text-primary leading-none">
                POLSEK TOLINGGULA
              </h1>
              <p className="text-sm font-medium text-muted-foreground tracking-wide mt-1">
                LAPORAN DIGITAL PIKET V3.0
              </p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-2">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 border border-green-200">
              <span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></span>
              Sistem Online
            </span>
          </div>
        </div>
      </div>
    </header>
  );
}
