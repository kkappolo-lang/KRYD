import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ShieldCheck, Plus, Trash2, Copy, MessageCircle, FileText, User, Users, Map, Clock, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { id as idLocale } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";
import type { PPGKData, PrisonerData, PatrolData } from "@shared/schema";
import { motion, AnimatePresence } from "framer-motion";

// Default data structures
const defaultPPGK: PPGKData = {
  I: "NIHIL", II: "NIHIL", III: "NIHIL", IV: "NIHIL", V: "NIHIL", VI: "NIHIL", 
  VII: "NIHIL", VIII: "NIHIL", 
  IX: "1. Personil Polsek Tolinggula melaksanakan tugas piket jaga Mako selama 1x24 jam\n\n2. Melaksanakan Patroli Rutin KRYD di wilayah hukum Polsek Tolinggula dan melaporkan hasilnya kepada Pimpinan.", 
  X: "NIHIL", XI: "NIHIL"
};

const defaultPrisoners: PrisonerData = {
  male: "Nihil", female: "Nihil", childMale: "Nihil", childFemale: "Nihil", provost: "Nihil"
};

const defaultPatrol: PatrolData = {
  start: "21:00", end: "22:00", leader: "BRIPKA NOLVIRANDA USMAN"
};

export default function ReportForm() {
  const { toast } = useToast();

  // State Management
  const [date, setDate] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [greeting, setGreeting] = useState<string>("Malam");
  const [teamNumber, setTeamNumber] = useState<string>("3 (TIGA)");
  const [personnel, setPersonnel] = useState<string[]>(["BRIPKA NOLVIRANDA USMAN", "BRIPKA INONG SARDINI", "BRIPKA MOHAMAD KHAIR", "BRIGADIR YUSRAN ANTULA", "BRIGADIR ANDIKA KALEF"]);
  const [attendance, setAttendance] = useState<Record<number, string>>({
    0: "Hadir", 1: "Hadir", 2: "Hadir", 3: "Hadir", 4: "Hadir"
  });
  const [ppgk, setPpgk] = useState<PPGKData>(defaultPPGK);
  const [prisoners, setPrisoners] = useState<PrisonerData>(defaultPrisoners);
  const [patrol, setPatrol] = useState<PatrolData>(defaultPatrol);
  const [previewText, setPreviewText] = useState("");

  const [activeTab, setActiveTab] = useState("personnel");

  // Personnel Handlers
  const addPersonnel = () => setPersonnel([...personnel, ""]);
  const removePersonnel = (index: number) => setPersonnel(personnel.filter((_, i) => i !== index));
  const updatePersonnel = (index: number, value: string) => {
    const newPersonnel = [...personnel];
    newPersonnel[index] = value;
    setPersonnel(newPersonnel);
  };

  // Generate Report Text
  useEffect(() => {
    const formattedDate = date ? format(new Date(date), "EEEE 'tgl' dd MMMM yyyy", { locale: idLocale }) : "-";
    const nextDay = date ? format(new Date(new Date(date).getTime() + 24 * 60 * 60 * 1000), "EEEE, dd MMMM yyyy", { locale: idLocale }) : "-";
    
    // Roman numerals for PPGK
    const romanLabels = [
      "I. KEJAHATAN KONVENSIONAL",
      "II. KEJAHATAN TRANS NASIONAL",
      "III. KEJAHATAN TERHADAP KEKAYAAN NEGARA",
      "IV. KEJAHATAN BERIMPLIKASI KONTIJENSI",
      "V. LAKA LANTAS",
      "VI. BENCANA ALAM",
      "VII. KASUS MENONJOL",
      "VIII. GIAT MASYARAKAT",
      "IX. GIAT KEPOLISIAN",
      "X. REN UNRAS",
      "XI. GIAT UNRAS"
    ];

    const ppgkValues = [
      ppgk.I || "- NIHIL.", ppgk.II || "- NIHIL.", ppgk.III || "- NIHIL.", ppgk.IV || "- NIHIL.",
      ppgk.V || "- NIHIL.", ppgk.VI || "- NIHIL.", ppgk.VII || "- NIHIL.", ppgk.VIII || "- NIHIL.",
      ppgk.IX || "1. Personil Polsek Tolinggula melaksanakan tugas piket jaga Mako selama 1x24 jam\n\n2. Melaksanakan Patroli Rutin KRYD di wilayah hukum Polsek Tolinggula dan melaporkan hasilnya kepada Pimpinan.", 
      ppgk.X || "- NIHIL.", ppgk.XI || "- NIHIL."
    ];

    const presentPersonnel = personnel.filter((p, i) => p.trim() && (attendance[i] === "Hadir" || !attendance[i]));
    const absentPersonnel = personnel.filter((p, i) => p.trim() && attendance[i] && attendance[i] !== "Hadir");
    
    const personnelList = personnel.filter(p => p.trim()).map((p, i) => {
      const statusValue = attendance[i] || "Hadir";
      const status = ` [${statusValue}]`;
      return `${i + 1}). ${p}${status}`;
    }).join("\n");

    const text = `*Assalamualaikum warahmatullahi wabarakatuh*
*Selamat ${greeting}*
*Salam Sejahtera*
*Salam Presisi*

*KEPADA YTH :*
*1. KAPOLDA GORONTALO*
*2. KAPOLRES GORONTALO UTARA*

*DARI:*
*KAPOLSEK TOLINGGULA* *Ijin melaporkan*

*PERIHAL* *KESIAPSIAGAAN PERSONIL POLSEK TOLINGGULA DALAM MELAKSANAKAN PIKET JAGA MAKO SELAMA 1 X 24 JAM*
*PADA HARI ${formattedDate.toUpperCase()} PUKUL 08.00 WITA SAMPAI DENGAN HARI ${nextDay.toUpperCase()} PUKUL 08.00 WITA*

*A. PERSONIL PIKET.*
Jumlah  : ${personnel.length}
Kurang  : ${absentPersonnel.length || "0"}
Hadir   : ${presentPersonnel.length || "0"}
Ket.    : ${absentPersonnel.length > 0 ? absentPersonnel.map((p) => {
      const idx = personnel.indexOf(p);
      const status = attendance[idx] || "Hadir";
      return `${p} (${status.toUpperCase()})`;
    }).join(", ") : "LENGKAP"}

*PIKET REGU ${teamNumber}*
${personnelList || "- Belum ada personil"}

*B. PERISTIWA PENTING GANGGUAN KAMTIBMAS (PPGK).*

${romanLabels.map((label, i) => `*${label}.*
${ppgkValues[i]}`).join("\n\n")}

*C. JUMLAH TAHANAN.*
- NIHIL 
*I. Tahanan*
1. Laki-laki : ${prisoners.male || "Nihil"}
2. Perempuan : ${prisoners.female || "Nihil"} 

*II. Anak-Anak*
1. Laki - laki : ${prisoners.childMale || "Nihil"}
2. Perempuan : ${prisoners.childFemale || "Nihil"} 

*III. TAHANAN PROVOST.*
- ${prisoners.provost ? prisoners.provost.toUpperCase() : "NIHIL"}.`;

    const krydText = `*Selamat ${greeting}*
*Ijin Melaporkan*
 
*PRIHAL: GIAT PATROLI KRYD DALAM WILAYAH HUKUM POLSEK TOLINGGULA*
 
Pada hari ${formattedDate}, Pkl. ${patrol.start} Wita, bertempat di Wilayah Hukum Polsek Tolinggula, Piket Regu ${teamNumber} Melaksanakan Giat Patroli KRYD dalam Rangka Mencegah Terjadinya Gangguan Kamtibmas yang terjadi di Wilayah Hukum Polsek Tolinggula, Giat Patroli dipimpin langsung oleh Ka Jaga Piket Regu ${teamNumber} ${patrol.leader || "................"}
 
@ Sasaran dari giat Patroli KRYD tsb  ; 
 
1. Mendatangi tempat- tempat keramaian yang dijadikan tempat berkumpul nya Masyarakat sehingga menimbulkan adanya kerumunan Masyarakat.
 
2. Memberikan himbaun tentang Kamtibmas kepada Masyarakat serta melakukan giat Patroli ke lokasi yang dianggap rawan, sehingga dapat mencegah terjadinya Kriminalitas yang bisa menimbulkan gangguan Kamtibmas di wilayah Hukum Polsek Tolinggula.
 
3. Dalam pelaksanaan giat Patroli KRYD merupakan kegiatan Rutin Yang Ditingkatkan yang dilaksanakan oleh Personil Polsek Tolinggula, untuk mengurangi dan Menekan angka Kriminalitas.
 
@ Dalam pelaksanaan giat Patroli KRYD yang menjadi target sasaran yakni tempat-tempat berkumpulnya masyarakat and tempat-tempat yang dianggap rawan akan  terjadinya gangguan kamtibmas.
 
@ Tujuan dilaksanakannya giat Patroli KRYD, untuk mencegah terjadinya Gangguan Kamtibmas di Wilayah Hukum Polsek Tolinggula.
 
@ Giat Patroli KRYD berakhir hingga Pkl. ${patrol.end} Wita, berjalan Lancar dan Kondusif
 
@ Demikian Laporan, Dan terima kasih`;

    setPreviewText(activeTab === "personnel" ? text : krydText);
  }, [date, greeting, teamNumber, personnel, attendance, ppgk, prisoners, patrol, activeTab]);

  // Actions
  const handleCopy = () => {
    navigator.clipboard.writeText(previewText);
    toast({ title: "Teks Disalin", description: "Laporan telah disalin ke clipboard." });
  };

  const handleWhatsApp = () => {
    const phoneNumber = "6285298833350";
    const url = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(previewText)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="flex flex-col gap-6 min-h-screen pb-10 px-4 md:px-0 max-w-7xl mx-auto">
      {/* HEADER SECTION - DATE & GREETING */}
      <Card className="border-t-4 border-t-primary shadow-md">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-primary font-bold text-lg">
              <FileText className="w-5 h-5" />
              Laporan Polsek Tolinggula
            </div>
            <div className="flex w-full sm:w-auto gap-2">
              <Input 
                type="date" 
                value={date} 
                onChange={(e) => setDate(e.target.value)} 
                className="h-10 bg-background flex-1 sm:w-40"
              />
              <Select value={greeting} onValueChange={setGreeting}>
                <SelectTrigger className="w-32 h-10 bg-background z-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent position="popper" sideOffset={4} className="min-w-[120px] z-[100] bg-white shadow-xl border">
                  <SelectItem value="Pagi">Pagi</SelectItem>
                  <SelectItem value="Siang">Siang</SelectItem>
                  <SelectItem value="Sore">Sore</SelectItem>
                  <SelectItem value="Malam">Malam</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* LEFT COLUMN - INPUTS */}
        <div className="flex flex-col gap-6">
          <Card className="border-t-4 border-t-primary shadow-lg overflow-hidden">
            <CardContent className="p-0">
              <Tabs defaultValue="personnel" className="w-full" onValueChange={setActiveTab}>
                <div className="px-4 pt-4">
                  <TabsList className="w-full grid grid-cols-2 bg-muted/50 p-1 h-12">
                    <TabsTrigger value="personnel" className="h-10 transition-all text-sm">
                      <Users className="w-4 h-4 mr-1 sm:mr-2" /> Kesiapsiagaan
                    </TabsTrigger>
                    <TabsTrigger value="kryd" className="h-10 transition-all text-sm">
                      <ShieldCheck className="w-4 h-4 mr-1 sm:mr-2" /> KRYD & Patroli
                    </TabsTrigger>
                  </TabsList>
                </div>

                <div className="px-4 py-4 sm:px-6">
                  {/* TAB 1: PERSONNEL & PPGK */}
                  <TabsContent value="personnel" className="space-y-6 mt-0">
                    <section className="space-y-4">
                      <Label className="text-lg font-display text-primary flex items-center gap-2">
                        <Users className="w-5 h-5" /> Personil Jaga
                      </Label>
                      <div className="flex items-center gap-2">
                         <Label className="text-xs text-muted-foreground font-bold">REGU:</Label>
                         <Input 
                          type="text" 
                          value={teamNumber} 
                          onChange={(e) => setTeamNumber(e.target.value)}
                          className="w-full h-10 font-bold"
                          placeholder="Contoh: 3 (TIGA)"
                        />
                      </div>
                      
                      <div className="grid gap-3">
                        {personnel.map((p, i) => (
                          <div key={i} className="flex flex-col gap-2 p-3 border rounded-lg bg-muted/20">
                            <div className="flex gap-2">
                              <Input 
                                placeholder={`Nama Personil ${i + 1}`} 
                                value={p}
                                onChange={(e) => updatePersonnel(i, e.target.value)}
                                className="flex-1 font-medium h-10"
                              />
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => removePersonnel(i)}
                                disabled={personnel.length === 1}
                                className="text-destructive hover:bg-destructive/10 h-10 w-10 shrink-0"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <Label className="text-[10px] uppercase font-bold text-muted-foreground whitespace-nowrap">Status:</Label>
                              <div className="flex-1">
                                <Select 
                                  value={attendance[i] || "Hadir"} 
                                  onValueChange={(v) => setAttendance({...attendance, [i]: v})}
                                >
                                  <SelectTrigger className="h-9 text-sm bg-background w-full z-0">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent position="popper" sideOffset={4} className="min-w-[150px] z-[100] bg-white shadow-xl border">
                                    <SelectItem value="Hadir">Hadir</SelectItem>
                                    <SelectItem value="Ijin">Ijin</SelectItem>
                                    <SelectItem value="Sakit">Sakit</SelectItem>
                                    <SelectItem value="Dinas Luar">Dinas Luar</SelectItem>
                                    <SelectItem value="Tanpa Keterangan">Tanpa Keterangan</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </div>
                        ))}
                        <Button variant="outline" onClick={addPersonnel} className="w-full h-10 border-dashed border-2 hover:border-primary hover:text-primary">
                          <Plus className="w-4 h-4 mr-2" /> Tambah Anggota
                        </Button>
                      </div>
                    </section>

                    <section className="space-y-4 pt-4 border-t">
                      <Label className="text-lg font-display text-primary flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5" /> Situasi Kamtibmas (PPGK)
                      </Label>
                      
                      <div className="grid gap-4">
                         <PPGKInput label="I. KONVENSIONAL" value={ppgk.I} onChange={(v) => setPpgk({...ppgk, I: v})} />
                         <PPGKInput label="II. TRANS NASIONAL" value={ppgk.II} onChange={(v) => setPpgk({...ppgk, II: v})} />
                         <PPGKInput label="III. KEKAYAAN NEGARA" value={ppgk.III} onChange={(v) => setPpgk({...ppgk, III: v})} />
                         <PPGKInput label="IV. KONTIJENSI" value={ppgk.IV} onChange={(v) => setPpgk({...ppgk, IV: v})} />
                         <PPGKInput label="V. LAKA LANTAS" value={ppgk.V} onChange={(v) => setPpgk({...ppgk, V: v})} />
                         <PPGKInput label="VI. BENCANA ALAM" value={ppgk.VI} onChange={(v) => setPpgk({...ppgk, VI: v})} />
                         <PPGKInput label="VII. KASUS MENONJOL" value={ppgk.VII} onChange={(v) => setPpgk({...ppgk, VII: v})} />
                         <PPGKInput label="VIII. GIAT MASYARAKAT" value={ppgk.VIII} onChange={(v) => setPpgk({...ppgk, VIII: v})} />
                         <PPGKInput label="IX. GIAT KEPOLISIAN" value={ppgk.IX} onChange={(v) => setPpgk({...ppgk, IX: v})} height="h-32" />
                         <PPGKInput label="X. REN UNRAS" value={ppgk.X} onChange={(v) => setPpgk({...ppgk, X: v})} />
                         <PPGKInput label="XI. GIAT UNRAS" value={ppgk.XI} onChange={(v) => setPpgk({...ppgk, XI: v})} />
                      </div>
                    </section>

                    <section className="space-y-4 pt-4 border-t">
                      <Label className="text-lg font-display text-primary flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5" /> Data Tahanan
                      </Label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <PrisonerInput label="Laki-laki Dewasa" value={prisoners.male} onChange={(v) => setPrisoners({...prisoners, male: v})} />
                        <PrisonerInput label="Perempuan Dewasa" value={prisoners.female} onChange={(v) => setPrisoners({...prisoners, female: v})} />
                        <PrisonerInput label="Anak Laki-laki" value={prisoners.childMale} onChange={(v) => setPrisoners({...prisoners, childMale: v})} />
                        <PrisonerInput label="Anak Perempuan" value={prisoners.childFemale} onChange={(v) => setPrisoners({...prisoners, childFemale: v})} />
                        <div className="sm:col-span-2">
                          <PrisonerInput label="Titipan Provost" value={prisoners.provost} onChange={(v) => setPrisoners({...prisoners, provost: v})} />
                        </div>
                      </div>
                    </section>
                  </TabsContent>

                  {/* TAB 2: KRYD */}
                  <TabsContent value="kryd" className="space-y-6 mt-0">
                    <section className="space-y-4">
                      <Label className="text-lg font-display text-primary flex items-center gap-2">
                        <Map className="w-5 h-5" /> Giat KRYD / Patroli
                      </Label>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-xs uppercase text-muted-foreground font-bold">Mulai (WITA)</Label>
                          <div className="relative">
                            <Clock className="absolute left-2.5 top-3 w-4 h-4 text-muted-foreground" />
                            <Input type="time" className="pl-9 h-10" value={patrol.start} onChange={(e) => setPatrol({...patrol, start: e.target.value})} />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs uppercase text-muted-foreground font-bold">Selesai (WITA)</Label>
                          <div className="relative">
                            <Clock className="absolute left-2.5 top-3 w-4 h-4 text-muted-foreground" />
                            <Input type="time" className="pl-9 h-10" value={patrol.end} onChange={(e) => setPatrol({...patrol, end: e.target.value})} />
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                         <Label className="text-xs uppercase text-muted-foreground font-bold">Nama Ka Jaga</Label>
                         <div className="relative">
                            <User className="absolute left-2.5 top-3 w-4 h-4 text-muted-foreground" />
                            <Input placeholder="Nama Ka Jaga" className="pl-9 h-10" value={patrol.leader} onChange={(e) => setPatrol({...patrol, leader: e.target.value})} />
                         </div>
                      </div>
                    </section>
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* RIGHT COLUMN - PREVIEW */}
        <div className="flex flex-col gap-4">
          <div className="lg:sticky lg:top-8 space-y-4">
            <Card className="overflow-hidden border-t-4 border-t-accent shadow-lg bg-slate-50">
              <CardHeader className="bg-white border-b py-3 px-4">
                 <CardTitle className="flex items-center gap-2 text-lg text-primary">
                    <FileText className="w-5 h-5" /> 
                    <span>Pratinjau Laporan</span>
                 </CardTitle>
              </CardHeader>
              <CardContent className="p-0 relative">
                <Textarea
                  className="w-full min-h-[400px] lg:min-h-[500px] p-4 resize-none focus:outline-none bg-slate-50 font-mono text-sm leading-relaxed text-slate-700 border-none rounded-none"
                  value={previewText}
                  readOnly
                />
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-col gap-3">
              <Button 
                size="lg"
                className="w-full h-14 bg-[#25D366] hover:bg-[#128C7E] text-white shadow-md hover:shadow-lg transition-all font-bold text-lg rounded-xl"
                onClick={handleWhatsApp}
              >
                <MessageCircle className="w-6 h-6 mr-2" /> KIRIM KE WHATSAPP
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                className="w-full h-12 border-primary/20 hover:bg-primary/5 hover:text-primary font-medium rounded-xl"
                onClick={handleCopy}
              >
                <Copy className="w-4 h-4 mr-2" /> Salin Teks Laporan
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper Components for Inputs
function PPGKInput({ label, value, onChange, height = "h-10", placeholder = "NIHIL" }: { label: string, value: string, onChange: (v: string) => void, height?: string, placeholder?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-bold text-muted-foreground uppercase">{label}</Label>
      {height === "h-10" ? (
        <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
      ) : (
        <Textarea value={value} onChange={(e) => onChange(e.target.value)} className={height} placeholder={placeholder} />
      )}
    </div>
  );
}

function PrisonerInput({ label, value, onChange }: { label: string, value: string, onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-bold text-muted-foreground uppercase">{label}</Label>
      <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder="Nihil" />
    </div>
  );
}
