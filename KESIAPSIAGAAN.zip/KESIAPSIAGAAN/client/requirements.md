## Packages
date-fns | Date manipulation for the report logic
framer-motion | Smooth animations for tab switching and previews

## Notes
The app replicates a specific police report format.
Report generation logic needs to run on the client side for real-time preview.
WhatsApp integration uses the `whatsapp://send` protocol.
