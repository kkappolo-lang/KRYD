import { reports, type Report, type InsertReport } from "@shared/schema";

export interface IStorage {
}

export class DatabaseStorage implements IStorage {
}

export const storage = new DatabaseStorage();
