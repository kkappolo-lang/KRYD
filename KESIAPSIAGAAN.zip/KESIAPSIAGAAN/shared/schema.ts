import { z } from "zod";

// Helper types for JSON columns to ensure type safety in frontend
export interface PPGKData {
  I: string;
  II: string;
  III: string;
  IV: string;
  V: string;
  VI: string;
  VII: string;
  VIII: string;
  IX: string;
  X: string;
  XI: string;
}

export interface PrisonerData {
  male: string;
  female: string;
  childMale: string;
  childFemale: string;
  provost: string;
}

export interface PatrolData {
  start: string;
  end: string;
  leader: string;
}
